//
//  WordsList.swift
//  Assignment
//
//  Created by Marcin Tomczuk on 02/12/2018.
//  Copyright © 2018 Marcin Tomczuk. All rights reserved.
//

import Foundation

struct WordsList: Codable {
    var word: String
    var meaning: String
}
